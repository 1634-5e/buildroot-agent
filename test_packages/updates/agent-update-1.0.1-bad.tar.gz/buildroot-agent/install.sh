#!/bin/bash
# Buildroot Agent 安装脚本

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY="${SCRIPT_DIR}/buildroot-agent"

echo "安装 Buildroot Agent..."
echo "版本信息:"
if [ -f "${SCRIPT_DIR}/VERSION" ]; then
    cat "${SCRIPT_DIR}/VERSION"
fi

echo ""
echo "二进制大小: $(stat -c%s "${BINARY}") bytes"
echo "二进制 MD5: $(md5sum "${BINARY}" | cut -d' ' -f1)"

# 设置执行权限
chmod +x "${BINARY}"

echo "安装完成!"
echo "请手动复制 buildroot-agent 到目标位置"
