# Buildroot Agent 更新包

版本: 1.0.1-corrupted
构建时间: 2026-02-12 17:55:11 UTC

## 文件说明
- `buildroot-agent`: 主要可执行文件
- `VERSION`: 版本信息文件
- `install.sh`: 安装脚本
- `README.md`: 说明文档

## 校验和
```
MD5: c35889115bb198b745fdcf0072e55174
SHA256: 719d69da48f2788bc535a8cfa50d8073fc25b75db48acc6a2aa997a49dad58c3
```
